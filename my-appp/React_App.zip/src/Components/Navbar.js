import React from "react";

export default function Navbar() {
    return (
        <nav className="Nav-bar">
        <h1 className="logo">Navbar </h1>
        <h2 className="members"> Members are: Maya, Charbel, Mohd </h2>
        </nav>
        
    )

}